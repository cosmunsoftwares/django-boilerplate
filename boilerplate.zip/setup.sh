

# sed -i 's/project_name/$1/g' myproject/wsgi.py


# wsgi.py
# settings.py
# urls.py # 2
# apps.py
# models.py
# Procfile
# manage.py
